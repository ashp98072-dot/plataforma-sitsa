SET @cb2_schema = _utf8mb4'cb2_lab';
START TRANSACTION; UPDATE flota_cb2_consumos SET vehiculo_id=999 WHERE id=1;