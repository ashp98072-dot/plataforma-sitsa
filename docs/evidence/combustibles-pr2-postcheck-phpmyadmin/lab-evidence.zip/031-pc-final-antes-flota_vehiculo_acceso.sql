SET @cb2_schema = _utf8mb4'cb2_lab';
SET time_zone='+00:00'; SET NAMES utf8mb4; START TRANSACTION WITH CONSISTENT SNAPSHOT;
SELECT COUNT(*) FROM `flota_vehiculo_acceso`;
SELECT IF(`vehiculo_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`vehiculo_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`vehiculo_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`empresa_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),'') FROM `flota_vehiculo_acceso`;
SELECT @@warning_count;
SELECT COUNT(*) FROM `flota_vehiculo_acceso`;
COMMIT; SELECT 'CB2_SNAPSHOT_END';
