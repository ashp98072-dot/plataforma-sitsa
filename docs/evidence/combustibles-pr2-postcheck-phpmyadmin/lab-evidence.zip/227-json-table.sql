SET @cb2_schema = _utf8mb4'cb2_lab';
SELECT SUM(j.n) FROM JSON_TABLE('[1,2]', '$[*]' COLUMNS(n INT PATH '$')) AS j;