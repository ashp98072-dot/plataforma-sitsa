SET @cb2_schema = _utf8mb4'cb2_lab';
SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='cb2_other';