SET @cb2_schema = _utf8mb4'cb2_lab';
SHOW CREATE TABLE auditoria;