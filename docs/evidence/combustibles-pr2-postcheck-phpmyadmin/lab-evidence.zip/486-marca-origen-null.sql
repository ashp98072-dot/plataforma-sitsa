SET @cb2_schema = _utf8mb4'cb2_lab';
START TRANSACTION; UPDATE flota_cb2_filas SET marca_origen=NULL WHERE id=1;