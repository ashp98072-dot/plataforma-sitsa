SET @cb2_schema = _utf8mb4'cb2_lab';
START TRANSACTION; UPDATE flota_cb2_filas SET decision='no-json' WHERE id=1;