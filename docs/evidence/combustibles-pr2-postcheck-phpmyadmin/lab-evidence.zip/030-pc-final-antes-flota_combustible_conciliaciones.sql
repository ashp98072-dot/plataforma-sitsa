SET @cb2_schema = _utf8mb4'cb2_lab';
SET time_zone='+00:00'; SET NAMES utf8mb4; START TRANSACTION WITH CONSISTENT SNAPSHOT;
SELECT COUNT(*) FROM `flota_combustible_conciliaciones`;
SELECT IF(`id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`empresa_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`proveedor_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`proveedor_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`proveedor_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`perfil_parser` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(`perfil_parser` AS BINARY)),0),IFNULL(HEX(CAST(`perfil_parser` AS BINARY)),''),IF(`archivo_sha256` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(`archivo_sha256` AS BINARY)),0),IFNULL(HEX(CAST(`archivo_sha256` AS BINARY)),'') FROM `flota_combustible_conciliaciones`;
SELECT @@warning_count;
SELECT COUNT(*) FROM `flota_combustible_conciliaciones`;
COMMIT; SELECT 'CB2_SNAPSHOT_END';
