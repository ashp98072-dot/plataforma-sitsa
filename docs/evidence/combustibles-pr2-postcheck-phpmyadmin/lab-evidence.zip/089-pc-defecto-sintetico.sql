SET @cb2_schema = _utf8mb4'cb2_lab';
UPDATE flota_cb2_filas SET operacion_total=3 WHERE operacion_tipo='REANUDAR';