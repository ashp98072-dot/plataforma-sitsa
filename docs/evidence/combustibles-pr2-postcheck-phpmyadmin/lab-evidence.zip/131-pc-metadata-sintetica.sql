SET @cb2_schema = _utf8mb4'cb2_lab';
ALTER TABLE flota_cb2_facturas MODIFY serie VARCHAR(127) NOT NULL;