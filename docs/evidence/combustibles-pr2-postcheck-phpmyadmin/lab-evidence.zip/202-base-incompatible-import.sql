SET @cb2_schema = _utf8mb4'cb2_lab';
ALTER TABLE auditoria MODIFY usuario VARCHAR(99) NULL;