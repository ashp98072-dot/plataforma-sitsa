SET @cb2_schema = _utf8mb4'cb2_lab';
SELECT VERSION(),@@sql_mode,@@innodb_page_size,@@foreign_key_checks,@@check_constraint_checks,@@group_concat_max_len,@@skip_networking,@@innodb_strict_mode;