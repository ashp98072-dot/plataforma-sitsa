SET @cb2_schema = _utf8mb4'cb2_lab';
CREATE DATABASE cb2_other;