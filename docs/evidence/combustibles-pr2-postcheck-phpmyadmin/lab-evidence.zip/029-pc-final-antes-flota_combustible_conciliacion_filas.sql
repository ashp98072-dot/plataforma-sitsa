SET @cb2_schema = _utf8mb4'cb2_lab';
SET time_zone='+00:00'; SET NAMES utf8mb4; START TRANSACTION WITH CONSISTENT SNAPSHOT;
SELECT COUNT(*) FROM `flota_combustible_conciliacion_filas`;
SELECT IF(`id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`empresa_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`empresa_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`conciliacion_id` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(CAST(`conciliacion_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),0),IFNULL(HEX(CAST(CAST(`conciliacion_id` AS CHAR CHARACTER SET utf8mb4) AS BINARY)),''),IF(`clave_operacion` IS NULL,'N','V'),IFNULL(OCTET_LENGTH(CAST(`clave_operacion` AS BINARY)),0),IFNULL(HEX(CAST(`clave_operacion` AS BINARY)),'') FROM `flota_combustible_conciliacion_filas`;
SELECT @@warning_count;
SELECT COUNT(*) FROM `flota_combustible_conciliacion_filas`;
COMMIT; SELECT 'CB2_SNAPSHOT_END';
